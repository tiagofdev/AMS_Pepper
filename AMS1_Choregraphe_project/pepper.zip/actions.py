# This files contains your custom actions which can be used to run
# custom Python code.
#
# See this guide on how to implement these action:
# https://rasa.com/docs/rasa/custom-actions

from typing import Any, Text, Dict, List
from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher
from bd.shedule import select_data_shedule
from bd.salles_disponibles import select_data_salles
from bd.orientation_batiment import select_data_orientation
from bd.texter_prof import select_data_send_message
from bd.meteo import select_data_meteo
import random
from rasa_sdk.events import EventType
from rasa_sdk.events import SlotSet



class ActionConsulterEdt(Action):

    def name(self) -> Text:
        return "action_consulter_edt"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        print("action consulter edt")

        site = tracker.get_slot("site")
        print("site: ", site)
        section = tracker.get_slot("section")
        print("section: ", section)
        groupe = tracker.get_slot("groupe")
        print("groupe: ", groupe)
        date = tracker.get_slot("date")
        print("date: ", date)

        valid_sites = ["ceri", "agroSciences", "avignon centre", "agroparc"]
        valid_sections = ["m1 ilsen", "m2 informatique", "l2 informatique", "l1 math"]
        valid_groupes = ["classique", "alternant", "groupe 1", "groupe 2"]
        valid_dates = ["08-11-2024", "demain", "maintenant", "05-11-2024", "dans une heure"]

        if site not in valid_sites or section not in valid_sections or groupe not in valid_groupes or date not in valid_dates:
            print("Aucune donnée disponible pour les paramètres fournis.")
            dispatcher.utter_message(text = "Désolé, aucun emploi du temps n'a été trouvé pour les informations fournies.")

        else:
            emploi_du_temps = select_data_shedule(site, section, groupe, date)
            if emploi_du_temps:
                print("Données récupérées: ", emploi_du_temps)
                result = format(emploi_du_temps)
                dispatcher.utter_message(text = result)

        print("reset success")
        return [SlotSet("site", None), SlotSet("section", None), SlotSet("groupe", None), SlotSet("date", None)]



class ActionSallesLibres(Action):

    def name(self) -> Text:
        return "action_salles_libres"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        print("Action consulter libres salles")
        print("")
        heure = tracker.get_slot("heure_salle")
        print("heure: ", heure)
        print("")

        valid_heures = ["dix heures", "dans 1h", "midi", "quatorze heures", "seize heures trente minutes", "treize heures trente minutes",
                        "maintenant", "huit heures", "neuf heures", "onze heures", "onze heures trente minutes", "dix-sept heures",
                        "seize heures", "huit heures trente minutes"]

        if heure not in valid_heures:
            print("Aucune donnée n'a été trouvé pour les informations fournis.")
            dispatcher.utter_message(text = "Désolé, aucune donnée n'a été trouvé pour les informations fournies.")

        else:
            select_heure = select_data_salles(heure)
            if select_heure:
                result = format(select_heure)
                print("result : ", result)
                dispatcher.utter_message(text = result)

        print("reset success")
        return [SlotSet("heure_salle", None)]


class ActionOrienterBatiment(Action):

    def name(self) -> Text:
        return "action_orienter_batiment"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        print("Action consulter orienter")
        print("")
        place = tracker.get_slot("place")
        print("place: ", place)
        print("")

        valid_places = ["salle 101", "salle 102", "amphi ada", "amphi blaise", "bâtiment du crous", "bureau du sécrétariat",
                        "bâtiment administratif", "laboratoire de chimie", "salle des professeurs", "bâtiment iut",
                        "bâtiment agrosciences", "salle c137", "cafétaria", "scolarité", "salle des robots", "toilettes",
                        "bâtiment du ceri", "salle 103", "laboratoire de physique", "bibliothèque universitaire"]
        if place not in valid_places:
            print("Aucune donnée n'a été trouvé pour les informations fournis.")
            dispatcher.utter_message(text = "Désolé, aucune donnée n'a été trouvé pour les informations fournies.")

        else:
            select_place = select_data_orientation(place)
            if select_place:
                result = format(select_place)
                print("result : ", result)
                dispatcher.utter_message(text = result)

        print("reset success")
        return [SlotSet("place", None)]


class ActionTexterProf(Action):

    def name(self) -> Text:
        return "action_texter_prof"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        print("Action consulter texter prof")
        print("")
        nom_prof = tracker.get_slot("nom_prof_tp")
        print("nom_prof_tp : ", nom_prof)
        formation_prof = tracker.get_slot("formation_occupee_tp")
        print("formation_occupee_tp ", formation_prof)
        niveau_prof = tracker.get_slot("niveau_tp")
        print("niveau_tp ", niveau_prof)

        print("")

        valid_noms = ["paul", "diallo"]
        valid_formations = ["physique", "math", "ams-projet", "anglais", "management"]
        valid_niveaux = ["l1", "l2", "m1", "licence 1", "licence 2", "master 1", "master 2", "l3", "licence 3"]

        if nom_prof not in valid_noms or formation_prof not in valid_formations or niveau_prof not in valid_niveaux:
            print("Aucune donnée n'a été trouvé pour les informations fournis.")
            dispatcher.utter_message(text = "Désolé, aucune donnée n'a été trouvé pour les informations fournies.")

        else:
            select_tp = select_data_send_message(nom_prof, formation_prof, niveau_prof)
            if select_tp:
                result = format(select_tp)
                print("result : ", result)
                dispatcher.utter_message(text = result)

        print("reset success")
        return [SlotSet("nom-prof_tp", None), SlotSet("formation_occupee_tp", None), SlotSet("niveau_tp", None)]


class ActionConsulterMeteo(Action):

    def name(self) -> Text:
        return "action_consulter_meteo"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        print("Action consulter meteo")
        print("")
        moment = tracker.get_slot("moment")
        print("date : ", moment)
        print("")

        valid_moments = ["aujourd'hui", "maintenant", "demain", "dans une heure", "nuit", "soir", "matinée", "après-midi", "matin",
                         "midi", "quatore heures", "dix heures", "douze heures", "minuit", "après-demain", "dix-sept heures",
                         "cinq heures du matin", "fin d'après-midi", "weekend", "tôt le matin", "pendant le déjeuner", "dix-neuf heures"]
        if moment not in valid_moments:
            print("Aucune donnée n'a été trouvé pour les informations fournis.")
            dispatcher.utter_message(text = "Désolé, aucune donnée n'a été trouvé pour les informations fournies.")

        else:
            select_moment = select_data_meteo(moment)
            if select_moment:
                result = format(select_moment)
                print("result : ", result)
                dispatcher.utter_message(text = result)

        print("reset success")
        return [SlotSet("moment", None)]


questions_de_relance = [
    "Est-ce que tu aimes faire du sport ?",
    "En quelle année d'université es-tu ?",
    "Sur quel site es-tu, comme CERI, Université Centre, Agrosciences ou IUT ?",
    "Quelle est ta nationalité ?",
    "Tu as quel âge?",
    "Comment-tu te sens?"
]


class ActionPoserQuestionReprise(Action):
    def name(self) -> Text:
        return "action_poser_question_reprise"

    def run(self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]) -> List[EventType]:
        question = random.choice(questions_de_relance)
        dispatcher.utter_message(text = question)
        return []


class ActionWaitUneMinute(Action):
    def name(self) -> Text:
        return "action_wait_une_minute"

    def run(self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]) -> list[
        list[dict[str, Any]]]:
        dispatcher.utter_message(text = "Hmm... tu es toujours là ?")
        return [ActionPoserQuestionReprise().run(dispatcher, tracker, domain)]
