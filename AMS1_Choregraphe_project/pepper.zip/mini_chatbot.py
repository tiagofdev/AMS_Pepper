from flask import Flask, request, jsonify, render_template
import requests

app = Flask(__name__)

RASA_URL = "http://localhost:5005/webhooks/rest/webhook"


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/chat', methods=['POST'])
def chat():
    user_message = request.json.get("message")

    if not user_message:
        return jsonify({
            "replies": ["Bonjour, bienvenue, Que puis-je faire pour vous?"]
        })

    response = requests.post(RASA_URL, json={"sender": "user", "message": user_message})
    bot_responses = response.json()
    print("Réponse de Rasa:", bot_responses)

    if bot_responses:
        replies = [resp.get("text", "") for resp in bot_responses]
        return jsonify({"replies": replies})
    else:
        return jsonify({"replies": ["Aucune réponse de la part du bot."]})



if __name__ == '__main__':
    app.run(debug=True)
